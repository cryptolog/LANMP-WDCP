#!/bin/bash
# wdcp tools
# change mysql root password
# author wdlinux
# url http://www.wdlinux.cn
/www/wdlinux/wdphp/bin/php /www/wdlinux/wdcp/task/mysql_wdcppw_chg.php
