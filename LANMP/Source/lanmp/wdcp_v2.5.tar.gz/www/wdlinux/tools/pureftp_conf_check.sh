#!/bin/bash
# wdcp tools
# pureftpd conf check
# author wdlinux
# url http://www.wdlinux.cn
/www/wdlinux/wdphp/bin/php /www/wdlinux/wdcp/task/pureftpd_pass_check.php
