#!/bin/bash
# wdcp tools
# ntp time
# author wdlinux
# url http://www.wdlinux.cn
/www/wdlinux/wdphp/bin/php /www/wdlinux/wdcp/task/wdcp_cdip.php
