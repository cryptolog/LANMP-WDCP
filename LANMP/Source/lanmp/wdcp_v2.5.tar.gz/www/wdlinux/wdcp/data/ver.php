<?
$wdcp_name="wdcp";
$wdcp_ver="v2.5.10";///
$wdcp_ver_date="20140213";//
?>